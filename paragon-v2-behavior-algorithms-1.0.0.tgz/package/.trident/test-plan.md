# THE BOILERPLATE CONTAINER TEST PLAN — THE UNIVERSALITY PROOF (2026-08-29)

## OBJECTIVE

Prove the universal Paragon V2 Behavior Algorithms boilerplate runs its COMPLETE
enforcement loop in a fresh container, driven by the TRADING and SALES domains
(NOT trident) — the universality claim ("this is still wired to the current
coding agent usecase" → the boilerplate must be a UNIVERSAL machine with EMPTY
SLOTS) — with the package integrity (tsc 0, the full battery green) mechanically
verified in the container runtime, not on the host.

## TOOLS UNDER TEST

The ParagonEngine integration spine (core/engine.ts — the composition of the
role gate, the classifier, the synapse, the machine, the gates, the collector,
the circuit, the dispatch), the three reference domains (config/trident,
config/trading, config/sales — the trading and sales domains are the
universality proof), the tier-proportional dispatch (actuation/dispatch.ts),
the compliance bridge (engine.observeTool → the pool insert + the tier reset),
the OFF kill switch (the level option), the OpenCodeAdapter (the platform
surface). BLAST RADIUS: the entire boilerplate — this is the FIRST container
deployment of the boilerplate as a standalone package; every file is in scope.

## TEST SCENARIOS

### S1 — THE AUTH PROBE (D.1, mandatory FIRST)
- WHAT: `bun --version` executes in the container.
- PASS: the version string ("1.") appears in the exec output (the runtime is
  alive; the toolchain works; the enforcement is not the thing under test here).
- FAIL: "command not found" or no output.

### S2 — THE PACKAGE INTEGRITY (the gates, in-container)
- WHAT: in the deployed boilerplate directory: `npx tsc --noEmit` then
  `bun test` (the full battery: 88 tests across 3 files).
- PASS: tsc exits 0 (no output errors); the bun test summary shows
  "88 pass" AND "0 fail".
- FAIL: any TS error output; any non-zero fail count; the test summary absent.

### S3 — THE TRADING + SALES UNIVERSALITY RECEIPT (the core proof)
- WHAT: `bun test tests/trading-e2e.test.ts` in the container. The test file
  emits console.log tokens ONLY on passing assertions — the tokens are
  mechanically bound to the test framework's pass state (the model cannot
  type them into existence without the code actually working).
- PASS tokens (each must appear in the tool-result/exec context):
  T1_TRADING_LADDER_PASS (the trading evasion → INTERVENING tier 1 + the
    [RISK STEER] append)
  T2_TRADING_COMPLY_PASS (the risk-engine instrument → tier 0 + the pool insert)
  T3_TRADING_STOPLOSS_PASS (the stop-loss family fires independently)
  T4_TRADING_MINIMAL_PAIR_PASS (the legit framing stays IDLE — the anti-regex
    proof in the trading domain)
  T5_TRADING_OFF_KILL_PASS (the OFF dial: the identical bait, zero lifts)
  T6_SALES_LADDER_PASS (the sales domain → the [SALES STEER] append)
  T7_SALES_COMPLY_PASS (the crm-lookup instrument → the tier reset)
- FAIL: "(fail)" appears anywhere in the test output; any pass token missing.

### S4 — THE EXPORT SURFACE (the package resolves end-to-end)
- WHAT: a script imports ./index.ts and asserts the surface:
  ParagonEngine is a function, OpenCodeAdapter is a function, the three
  domains load with the correct names, a trading-domain engine drives the
  ladder end-to-end.
- PASS: "HAS_ENGINE: true", "HAS_OPENCODE_ADAPTER: true",
  "TRADING_LADDER: INTERVENING tier 1", "[RISK STEER]" in the injected head.
- FAIL: any "undefined" for the exports; the ladder fails to lift.

## ADVERSARIAL

### A1 — THE HOSTILE INPUT SWEEP
- WHAT: a bounded script drives engine.observeText with: empty string,
  100KB of text, regex-special-chars-only text, an emoji-only string, and a
  null-ish session id. The engine must NOT throw and must NOT lift the
  machine on garbage-only input.
- PASS: "ADVERSARIAL_SURVIVED" prints; every garbage session's record reads
  IDLE; no exceptions escape.
- FAIL: any thrown exception reaching the test; "MONITORING" on a
  garbage-only session (the false-positive lift class).

## EVIDENCE

Per-scenario exec outputs captured in the tool-result context; the bun test
summaries; the console.log token lines; the results artifact
(.trident/container-test-results-boilerplate.json) written by the rig with
the per-scenario verdicts. The container name + the deploy sha recorded.

## PASS CRITERIA (the Phase-E bar)

ALL scenarios executed (none skipped); every passToken present in the
tool-result context; every failToken absent; no circular passes (the tokens
are framework-bound, not agent-typeable); the container alive at the end;
the results artifact written. Any single failure = the overall verdict FAIL —
fix, redeploy, re-run.
